EN: First Time You Launch it will be error click ignore

PL: Przy pierwszym uruchomieniu wystąpi błąd kliknij ignoruj